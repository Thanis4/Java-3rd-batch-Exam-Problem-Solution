
public class TestCase {
	private int testCaseNumber;
	
	
	private String description;
	private TestData testData=new TestData();
	
	public int getTestCaseNumber() {
		return testCaseNumber;
	}
	public String getDescription() {
		return description;
	}
	
	public TestCase(int _testCaseNumber, String _description) {
		this.testCaseNumber=_testCaseNumber;
		this.description=_description;
		
	}
	@Override 
	public String toString() {
	String format="Testcase %d:%s. Data: %s";
	String unScrubbedData=testData.getData(testCaseNumber);
	String ScrubbedData=Helper.ScrubCreditCardData(unScrubbedData);
	String output=String.format(format, testCaseNumber,description,ScrubbedData);
		return output;
	}
}

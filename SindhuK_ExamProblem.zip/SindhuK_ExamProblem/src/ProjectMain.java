import java.util.ArrayList;
import java.util.List;

public class ProjectMain {

	public static void main(String[] args) {
		
	List<TestCase> testCases= new ArrayList<TestCase>();
	testCases.add(new TestCase(1,"Test a valid credit card"));
	testCases.add(new TestCase(2,"Test another valid credit card"));
	testCases.add(new TestCase(3,"Test an invalid credit card"));
	testCases.add(new TestCase(4,"Test Exceptions"));
	
	try {
	for(int i=0; i<4;i++) {
		TestCase tc=testCases.get(i);
		String tcDescription=tc.getDescription();
		int tcNumber=tc.getTestCaseNumber();
		String format="Processing Testcase :%d: %s";
		System.out.println(String.format(format,tcNumber,tcDescription));
		String output=tc.toString();
		System.out.println(output);
	
	}
	}
	catch(NullPointerException e) {
System.out.println("Exception occured. No test data available " +e.getStackTrace());

	}
	}

	
}

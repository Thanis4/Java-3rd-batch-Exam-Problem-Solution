import java.util.ArrayList;
import java.util.List;

/**
 * Main class of the exam;
 * 
 * @author MORARA2
 *
 */
public class ProjectMain {

	public static void main(String[] args) {

		
		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
		
		
		try {
			for (TestCase testCase : testCases) {
				//get the description from the testcase
				String tcDescription = testCase.getDescription();
				// get the test case number from the testcase
				int tcNumber = testCase.getTestCaseNumber();
				// setup a format match the expected output
				String format = "Processing testcase %d: %s";
				System.out.println(String.format(format, tcNumber, tcDescription));
				System.out.println(testCase.toString());
			}
			
		}
		catch(NullPointerException npex) {
			System.out.println("A NullpointerException was triggered. It was caused by a testcase with no data");
		}
		catch(Exception ex) {
			ex.printStackTrace(System.out);
		}
		
		
/*
//	Trying the Helper method
		String cardNumber1 = "1234-5678-9012";
		String cardNumber2 = "1234-A777-4567";
		
		System.out.println( Helper.ScrubCreditCardData(cardNumber1));
		System.out.println( Helper.ScrubCreditCardData(cardNumber2));
*/	
	
	}

}

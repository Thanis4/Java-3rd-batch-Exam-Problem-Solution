/**
 * 
 * @author MORARA2
 *
 */
public class Helper {

	/**
	 * This function takes in data and if it contains a credit card number, the
	 * number is replaced with dummy data (scrubbed) and the dummy data is returned
	 *
	 * @param _inputData The data to be scrubbed
	 * @return the modified data
	 */
	public static String ScrubCreditCardData(String _inputData) {
		String regexPattern = "[0-9]{4}-[0-9]{4}-[0-9]{4}";
		boolean isValidCreditCard = false;
		String output = "";

		isValidCreditCard = _inputData.matches(regexPattern);
		if (isValidCreditCard) {
			output = _inputData.replaceAll("[0-9]{4}", "XXXX");
		} else {
			output="<INVALID_CARD>";
			//System.out.println("<INVALID_CARD>");
		}
		return output;
	}
}

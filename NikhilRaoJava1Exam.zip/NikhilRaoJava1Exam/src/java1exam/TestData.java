package java1exam;
import java.util.HashMap;
public class TestData {
	HashMap<Integer, String> data = new HashMap<Integer, String>();

	public TestData()
	{
		//String[] _testCaseNumber = new String[3];
		data.put(1, "1234-5678-9012");
		data.put(2, "0000-0000-0000");
		data.put(3, "1234-AAAA-4567");
	}

	/**
	*
	* @param _testCaseNumber the testcase number (also the Map's key)
	* @return the data for the given test case number
	*/
	public String getData(int _testCaseNumber)
	{
		String output = data.get(_testCaseNumber);
		return output;
	}
}

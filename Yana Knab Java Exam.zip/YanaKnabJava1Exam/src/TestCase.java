

public class TestCase {

	private int testCaseNumber;
	public int getTestCaseNumber() {
		return testCaseNumber;
	}

	public void setTestCaseNumber(int testCaseNumber) {
		this.testCaseNumber = testCaseNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	private String description;
	TestData testData = new TestData();
	
	public TestCase(int _testCaseNumber, String _description)
	{
		// set the values of the private variables here with the arguments given to the constructor
		setTestCaseNumber(_testCaseNumber);
		setDescription(_description);
	}
	
	@Override
	public String toString()
	{
		// format should contain a format that matches the expected output below
		String format = "TestCase %d: %s. Data: %s";
		// unScrubbedData should pull the data out of the TestData class based on the test case number
		String unScrubbedData = testData.getData(testCaseNumber);
		// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
		String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData);
		String output = String.format(format, testCaseNumber, description, scrubbedData);
		return output;
	}
	
	
	
	

}

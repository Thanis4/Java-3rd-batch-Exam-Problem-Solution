import java.util.ArrayList;
import java.util.List;

/**
 * @author JALANP3
 * This is the main class of the project PoojaJalanJava1Exam
 *
 */
public class ProjectMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));

		try{                
            for(TestCase testcase:testCases){
                   //get the description from the testcase
                   String tcDescription = testcase.getDescription();
                   // get the test case number from the testcase
                   int tcNumber = testcase.getTestcaseNumber();
                   
                   // setup a format for String.format to match the expected output for "Processing testcase" output
                   String format = "Processing a test case: %d : %s ";
                   // put the arguments for String.format in the correct order
                   System.out.println(String.format(format,tcNumber,tcDescription));
                   System.out.println(testcase.toString());

            }      
     }catch(NullPointerException e){
            System.out.println("A "+e+ "was triggered. It was caused by a testcase with no data");
     }
     catch(Exception e){
            e.printStackTrace();
     }

		}
		
		
		
	}



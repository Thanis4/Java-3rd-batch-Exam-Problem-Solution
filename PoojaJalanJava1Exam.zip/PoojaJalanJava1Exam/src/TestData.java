import java.util.HashMap;
import java.util.Map;

public class TestData {

	Map<Integer,String> data  = new HashMap<Integer, String>();
	
	public TestData()
	{
		
	data.put(1, "1234-5678-9012");
	data.put(2, "4562-7890-1267");
	data.put(3, "1234-AAAA-4567");
	
	}
		
	
	public String getData(int _testCaseNumber)
	{
	String output = data.get(_testCaseNumber);
	return output;
	}
	
}

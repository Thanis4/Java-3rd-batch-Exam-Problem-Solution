package com.assignment;


import java.util.ArrayList;
import java.util.List;

public class ProjectMain {
	
	//TestCase testcase = new TestCase(0, null);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProjectMain projectmain = new ProjectMain();
		
		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
		
		
		for (TestCase test : testCases)
            
        {
      	//System.out.println(test);
       	projectmain.Testing(test);
        }

	}
	
	
	public void Testing(TestCase test) {
        try {
           
        	
        	//get the description from the testcase
        	
        	//System.out.println(test.getDescription());
    		String tcDescription = test.getDescription();
    		
    		//System.out.println(tcDescription);
    		
    		// get the test case number from the testcase
    		int tcNumber = test.getTestCaseNumber();
    		// setup a format for String.format to match the expected output for "Processing testcase" output
    		String format = "Processing testcase: %d : %s";
    		// put the arguments for String.format in the correct order
    		System.out.println(String.format(format, tcNumber, tcDescription));
    		System.out.println(test.toString());
        	
        	
        } catch (NullPointerException e) {
            System.err.println("A NullpointerException was triggered. It was caused by a testcase with no data");
        }
    }
	

}

package com.assignment;


public class TestCase {
	
	private int _testCaseNumber;
	
	private String _description; 
	
	TestData testdata = new TestData();
	
	Helper helper = new Helper();
	
	public TestCase(int _testCaseNumber, String _description)
	{
		
		this._testCaseNumber = _testCaseNumber;
		
		//System.out.println(_testCaseNumber);
		this._description= _description;
		//System.out.println(_description);
		
	// set the values of the private variables here with the arguments given to the constructor
	}
	
	public int getTestCaseNumber()
	{
	
	return _testCaseNumber;
	}
	
	public String getDescription()
	{
	
	return _description;
	}
	
	
	@Override
	public String toString()
	{
	// format should contain a format that matches the expected output below
	String format = "TestCase %d: %s. Data: %s";
	// unScrubbedData should pull the data out of the TestData class based on the test case number
	String unScrubbedData = testdata.getData(getTestCaseNumber());
	// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
	String scrubbedData = helper.ScrubCreditCardData(unScrubbedData);
	
	String output = String.format(format, getTestCaseNumber(), getDescription(), scrubbedData);
	return output;
	}

}

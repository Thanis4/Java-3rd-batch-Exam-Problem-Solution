package com.assignment;


import java.util.regex.Pattern;

public class Helper {


/**
* This function takes in data and if it contains a credit card number,
* the number is replaced with dummy data (scrubbed)
* and the dummy data is returned
*
* @param _inputData The data to be scrubbed
* @return the modified data
*/
public static String ScrubCreditCardData(String _inputData)
{
// define a regular expression pattern below:
String regexPattern = "^\\d{4}-\\d{4}-\\d{4}$";


// apply the pattern to the inputData
// and store the result in the boolean variable below

//System.out.println(_inputData);

boolean isValidCreditCard = Pattern.matches (regexPattern, _inputData);

//System.out.println(isValidCreditCard);
//boolean isValidCreditCard = false;
String output = "";
// fill out the following code
if (isValidCreditCard)
{
// scrub the data here. output should contain
// the value of the scrubbed data
	output = _inputData.replaceAll("\\d+", "9999");
	
}
else
{
	output = "<INVALID_CARD>";
// System.out.println ("<INVALID_CARD>");
}
return output;
}

}
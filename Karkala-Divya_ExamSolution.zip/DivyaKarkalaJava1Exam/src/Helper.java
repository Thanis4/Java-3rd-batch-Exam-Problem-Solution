
public class Helper {
	
	public static String ScrubCreditCardData(String InputData)
	{
		String regexPattern = "[0-9]{4}-[0-9]{4}-[0-9]{4}";
		boolean isValidCreditCard = false;
		isValidCreditCard= InputData.matches(regexPattern);
		String output ="";
		
		if (isValidCreditCard) {
			
			output=InputData.replaceAll("[0-9]{4}", "####");
			
						}
	 else
			{	
			output="<INVALID_CARD>"; 
			}
		
		return output;
	}

}

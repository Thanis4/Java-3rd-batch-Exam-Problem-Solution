
public class TestCase
{
	private int _testCaseNumber;

	public int get_testCaseNumber()
	{
		return _testCaseNumber;
	}

	private String _description;

	public String get_description()
	{
		return _description;
	}

	TestData testData = new TestData();

	public TestCase(int _testCaseNumber, String _description)
	{
		this._testCaseNumber = _testCaseNumber;
		this._description = _description;

		// set the values of the private variables here with the arguments given to the
		// constructor
	}

	@Override
	public String toString()
	{
		// format should contain a format that matches the expected output below
		String format = "TestCase %d: %s Data: %s";
		// unScrubbedData should pull the data out of the TestData class based on the
		// test case number
		String unScrubbedData = testData.getData(_testCaseNumber);
		// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
		String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData);
		String output = String.format(format, _testCaseNumber, _description, scrubbedData);
		return output;
	}
}
